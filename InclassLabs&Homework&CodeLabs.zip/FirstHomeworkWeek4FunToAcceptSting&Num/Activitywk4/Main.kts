fun displayOddEvenNumbers(number: Int, type: String) {
    if (type.lowercase() == "even") {
        println("Even numbers up to $number:")
        for (i in 0..number step 2) {
            println(i)
        }
    } else if (type.lowercase() == "odd") {
        println("Odd numbers up to $number:")
        for (i in 1..number step 2) {
            println(i)
        }
    } else {
        println("Invalid type. Please enter 'odd' or 'even'.")
    }
}

fun main() {
    displayOddEvenNumbers(10, "even")
    displayOddEvenNumbers(15, "odd")
    displayOddEvenNumbers(20, "Invalid")
}
